package com.adserver.exception;

@SuppressWarnings("serial")
public class ActiveCampaignException extends RuntimeException {

	public ActiveCampaignException(String message) {
		super(message);
	}
}