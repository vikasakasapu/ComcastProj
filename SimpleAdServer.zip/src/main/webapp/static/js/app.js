'use strict';

var App = angular.module('myApp',[]);


